//
//  ViewController.m
//  tcptest
//
//  Created by luodp on 16/4/18.
//  Copyright © 2016年 zhanghao. All rights reserved.
//

#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#import "ViewController.h"
#include <stdlib.h>
#include <errno.h>

#import <SystemConfiguration/CaptiveNetwork.h>

#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <dlfcn.h>


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    // Do any additional setup after loading the view, typically from a nib.
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    
    struct sockaddr_in addr;
    addr.sin_addr.s_addr = 0;
    addr.sin_port = htons(8080);
    addr.sin_family = AF_INET;
    
    struct sockaddr_in clientAddr;
    clientAddr.sin_addr.s_addr = 0;
    clientAddr.sin_port = htons(INADDR_ANY);
    clientAddr.sin_family = AF_INET;
    int len = sizeof(socklen_t);
    
    
    int ret = bind(fd, (struct sockaddr*)&addr, sizeof(addr));
    if(ret < 0)
    {
        perror("bind");
        return ;
    }
    
    listen(fd, 10);
    
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        while(1)
        {
            // this is new connect
            int conn = accept(fd, (struct sockaddr *)&clientAddr, &len);
            
            if(conn > 0)
            {
                printf("has new connect %d\n", conn);
                
                char buf[1024];
                recv(conn, buf, sizeof(buf), 0);
                printf("%s \n",inet_ntoa(clientAddr.sin_addr));
                printf("recv data is: %s\n", buf);
                
                send(conn, "hello ack", 10, 0);
            }
        }
    });
    
    while (1) {
        [self sendUDPDataPackage];
        sleep(10);
    }
  
    
    

    
}



-(int)sendUDPDataPackage{
    char message[40] = "dsafasdfsadfsadf";
    int brdcFd;
    brdcFd = socket(PF_INET, SOCK_DGRAM, 0);
    if (brdcFd == -1) {
        printf("socket fail\n");
        return -1;
    }
    int optval = 1;
    NSLog(@"setsockopt:%d",setsockopt(brdcFd, SOL_SOCKET, SO_BROADCAST, &optval, sizeof(optval)));
    struct sockaddr_in theirAddr;
    memset(&theirAddr, 0, sizeof(struct sockaddr_in));
    theirAddr.sin_family = AF_INET;
    theirAddr.sin_addr.s_addr = inet_addr("255.255.255.255");
    theirAddr.sin_port = htons(43708);
    
    
    int sendBytes;
    if ((sendBytes = sendto(brdcFd, message, strlen(message), 0, (struct sockaddr *)&theirAddr, sizeof(struct sockaddr_in)))==-1) {
        printf("sendto fail,error = %d\n",errno);
        return -1;
    }
    printf("message = %s,msglen = %zu,sendBytes = %d\n",message,strlen(message),sendBytes);
    close(brdcFd);
    return 0;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
